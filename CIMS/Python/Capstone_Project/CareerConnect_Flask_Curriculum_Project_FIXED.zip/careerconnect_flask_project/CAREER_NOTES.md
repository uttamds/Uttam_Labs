# Interview / extension questions

1. Trace `/dashboard` from browser to database and back.
2. Why hash passwords instead of storing them as plain text?
3. What does SQLAlchemy ORM provide?
4. What is the difference between a Flask page route and a REST endpoint?
5. Why use `fetch()` instead of reloading the entire page?
6. Where are sessions/cookies involved?
7. Why use environment variables for secrets?
8. How would you add pagination?
9. How would you replace SQLite with MySQL?
10. How would you add automated tests?

Extension tasks:
- Add a Company model.
- Add job search and pagination.
- Add an admin role.
- Add profile image upload.
- Add pytest tests.
- Add CSRF protection.
- Deploy using a production WSGI server.
