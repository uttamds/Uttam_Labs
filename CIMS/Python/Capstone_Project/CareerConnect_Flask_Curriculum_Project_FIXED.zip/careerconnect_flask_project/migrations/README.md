# Migration basics

After changing a SQLAlchemy model:

flask --app run.py db migrate -m "describe change"
flask --app run.py db upgrade

For a fresh migration directory:
flask --app run.py db init

The demo database is created by `python seed.py`.
