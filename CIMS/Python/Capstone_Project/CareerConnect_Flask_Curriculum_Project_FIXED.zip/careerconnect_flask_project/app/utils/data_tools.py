import re

def clean_text(value):
    value = (value or "").strip()
    return re.sub(r"\s+", " ", value)

def skill_list(skills):
    return [clean_text(x) for x in (skills or "").split(",") if clean_text(x)]

def skill_summary(skills):
    return sorted(set(skill_list(skills)))

def salary_bands(jobs):
    return ["High" if j.salary >= 40000 else "Standard" for j in jobs]

def average_salary(jobs):
    salaries = [j.salary for j in jobs]
    return sum(salaries) / len(salaries) if salaries else 0

def safe_int(value, default=0):
    try:
        return int(value)
    except (TypeError, ValueError):
        return default
