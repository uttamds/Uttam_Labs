from abc import ABC, abstractmethod
from functools import reduce

class ReportStrategy(ABC):
    @abstractmethod
    def build(self, applications):
        raise NotImplementedError

class ApplicationReportStrategy(ReportStrategy):
    def build(self, applications):
        statuses = [x.status for x in applications]
        unique_statuses = set(statuses)
        counts = {s: statuses.count(s) for s in unique_statuses}
        active = list(filter(lambda x: x.status != "Rejected", applications))
        salaries = list(map(lambda x: x.job.salary, active))
        salary_sum = reduce(lambda a, b: a + b, salaries, 0)
        return {
            "total": len(applications),
            "active_count": len(active),
            "status_counts": counts,
            "salary_sum": salary_sum
        }

class CareerReportService:
    def __init__(self, strategy=None):
        self._strategy = strategy or ApplicationReportStrategy()

    def build_report(self, applications):
        return self._strategy.build(applications)
