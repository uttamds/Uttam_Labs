import csv
import io
from functools import wraps
from flask import Blueprint, Response, flash, redirect, render_template, request, session, url_for
from app import db
from app.models import User, Job, JobApplication
from app.services.career_service import CareerReportService

main = Blueprint("main", __name__)

def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if "user_id" not in session:
            flash("Please log in first.", "warning")
            return redirect(url_for("auth.login"))
        return view(*args, **kwargs)
    return wrapped

@main.app_context_processor
def inject_user():
    user = User.query.get(session.get("user_id")) if session.get("user_id") else None
    return {"current_user": user}

@main.route("/")
def index():
    return render_template("index.html")

@main.route("/dashboard")
@login_required
def dashboard():
    user = User.query.get_or_404(session["user_id"])
    applications = JobApplication.query.filter_by(user_id=user.id).all()
    report = CareerReportService().build_report(applications)
    return render_template("dashboard.html", user=user, applications=applications, report=report)

@main.route("/profile", methods=["GET", "POST"])
@login_required
def profile():
    user = User.query.get_or_404(session["user_id"])
    if request.method == "POST":
        user.name = request.form.get("name", "").strip()
        user.skills = request.form.get("skills", "").strip()
        user.career_goal = request.form.get("career_goal", "").strip()
        db.session.commit()
        flash("Profile updated.", "success")
    return render_template("profile.html", user=user)

@main.route("/applications/new", methods=["GET", "POST"])
@login_required
def create_application():
    jobs = Job.query.order_by(Job.title).all()
    if request.method == "POST":
        job = Job.query.get_or_404(request.form.get("job_id", type=int))
        db.session.add(JobApplication(
            user_id=session["user_id"], job_id=job.id,
            status=request.form.get("status", "Applied"),
            notes=request.form.get("notes", "").strip()
        ))
        db.session.commit()
        flash("Application added.", "success")
        return redirect(url_for("main.dashboard"))
    return render_template("application_form.html", jobs=jobs, application=None)

@main.route("/applications/<int:application_id>/edit", methods=["GET", "POST"])
@login_required
def edit_application(application_id):
    app_item = JobApplication.query.filter_by(
        id=application_id, user_id=session["user_id"]).first_or_404()
    jobs = Job.query.order_by(Job.title).all()
    if request.method == "POST":
        app_item.job_id = request.form.get("job_id", type=int)
        app_item.status = request.form.get("status", "Applied")
        app_item.notes = request.form.get("notes", "").strip()
        db.session.commit()
        flash("Application updated.", "success")
        return redirect(url_for("main.dashboard"))
    return render_template("application_form.html", jobs=jobs, application=app_item)

@main.post("/applications/<int:application_id>/delete")
@login_required
def delete_application(application_id):
    item = JobApplication.query.filter_by(
        id=application_id, user_id=session["user_id"]).first_or_404()
    db.session.delete(item)
    db.session.commit()
    flash("Application deleted.", "info")
    return redirect(url_for("main.dashboard"))

@main.route("/jobs/<int:job_id>")
def job_detail(job_id):
    return render_template("job_detail.html", job=Job.query.get_or_404(job_id))

@main.route("/applications/export")
@login_required
def export_applications():
    items = JobApplication.query.filter_by(user_id=session["user_id"]).all()
    out = io.StringIO()
    writer = csv.writer(out)
    writer.writerow(["Job", "Company", "Status", "Notes", "Applied On"])
    for item in items:
        writer.writerow([item.job.title, item.job.company, item.status, item.notes,
                          item.applied_on.strftime("%Y-%m-%d") if item.applied_on else ""])
    return Response(out.getvalue(), mimetype="text/csv",
                    headers={"Content-Disposition": "attachment; filename=applications.csv"})
