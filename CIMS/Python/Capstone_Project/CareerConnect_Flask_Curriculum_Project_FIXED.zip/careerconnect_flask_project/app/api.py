from flask import Blueprint, jsonify, request, session
from app import db
from app.models import Job, JobApplication

api = Blueprint("api", __name__)

def current_user_id():
    return session.get("user_id")

@api.get("/health")
def health():
    return jsonify({"status": "ok", "service": "CareerConnect API"})

@api.get("/jobs")
def jobs():
    skill = request.args.get("skill", "").strip().lower()
    items = Job.query.all()
    if skill:
        items = [j for j in items if skill in j.skill.lower()]
    return jsonify({"count": len(items), "jobs": [j.to_dict() for j in items]})

@api.get("/jobs/<int:job_id>")
def job(job_id):
    return jsonify(Job.query.get_or_404(job_id).to_dict())

@api.get("/applications")
def applications():
    uid = current_user_id()
    if not uid:
        return jsonify({"error": "Login required"}), 401
    return jsonify([x.to_dict() for x in JobApplication.query.filter_by(user_id=uid).all()])

@api.post("/applications")
def create_application():
    uid = current_user_id()
    if not uid:
        return jsonify({"error": "Login required"}), 401
    data = request.get_json(silent=True) or {}
    job = Job.query.get(data.get("job_id"))
    if not job:
        return jsonify({"error": "Job not found"}), 404
    item = JobApplication(user_id=uid, job_id=job.id,
                          status=data.get("status", "Applied"),
                          notes=data.get("notes", ""))
    db.session.add(item)
    db.session.commit()
    return jsonify(item.to_dict()), 201

@api.put("/applications/<int:application_id>")
def update_application(application_id):
    uid = current_user_id()
    if not uid:
        return jsonify({"error": "Login required"}), 401
    item = JobApplication.query.filter_by(id=application_id, user_id=uid).first_or_404()
    data = request.get_json(silent=True) or {}
    item.status = data.get("status", item.status)
    item.notes = data.get("notes", item.notes)
    db.session.commit()
    return jsonify(item.to_dict())

@api.delete("/applications/<int:application_id>")
def delete_application(application_id):
    uid = current_user_id()
    if not uid:
        return jsonify({"error": "Login required"}), 401
    item = JobApplication.query.filter_by(id=application_id, user_id=uid).first_or_404()
    db.session.delete(item)
    db.session.commit()
    return jsonify({"message": "Application deleted"})
