from datetime import datetime
from app import db, bcrypt

class User(db.Model):
    __tablename__ = "users"
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(150), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    skills = db.Column(db.Text, default="")
    career_goal = db.Column(db.String(200), default="")
    applications = db.relationship("JobApplication", back_populates="user",
                                    cascade="all, delete-orphan")

    def set_password(self, password):
        self.password_hash = bcrypt.generate_password_hash(password).decode()

    def check_password(self, password):
        return bcrypt.check_password_hash(self.password_hash, password)

class Job(db.Model):
    __tablename__ = "jobs"
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(150), nullable=False)
    company = db.Column(db.String(150), nullable=False)
    location = db.Column(db.String(100), nullable=False)
    skill = db.Column(db.String(100), nullable=False)
    salary = db.Column(db.Integer, nullable=False)
    applications = db.relationship("JobApplication", back_populates="job")

    def to_dict(self):
        return {"id": self.id, "title": self.title, "company": self.company,
                "location": self.location, "skill": self.skill, "salary": self.salary}

class JobApplication(db.Model):
    __tablename__ = "job_applications"
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    job_id = db.Column(db.Integer, db.ForeignKey("jobs.id"), nullable=False)
    status = db.Column(db.String(50), default="Applied")
    notes = db.Column(db.Text, default="")
    applied_on = db.Column(db.DateTime, default=datetime.utcnow)
    user = db.relationship("User", back_populates="applications")
    job = db.relationship("Job", back_populates="applications")

    def to_dict(self):
        return {
            "id": self.id, "job_id": self.job_id,
            "job_title": self.job.title if self.job else None,
            "company": self.job.company if self.job else None,
            "status": self.status, "notes": self.notes,
            "applied_on": self.applied_on.isoformat() if self.applied_on else None
        }
