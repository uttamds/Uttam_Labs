async function fetchMyApplications() {
    const response = await fetch("/api/applications");
    if (!response.ok) throw new Error("Could not load applications");
    return await response.json();
}
