async function loadJobs(skill = "") {
    const list = document.getElementById("jobList");
    list.innerHTML = "<div class='col-12 text-muted'>Loading...</div>";
    try {
        const response = await fetch(`/api/jobs${skill ? `?skill=${encodeURIComponent(skill)}` : ""}`);
        if (!response.ok) throw new Error("Unable to fetch opportunities");
        const data = await response.json();
        renderJobs(data.jobs);
    } catch (error) {
        list.innerHTML = `<div class="col-12 text-danger">${error.message}</div>`;
    }
}

function renderJobs(jobs) {
    const list = document.getElementById("jobList");
    if (!jobs.length) {
        list.innerHTML = "<div class='col-12 text-muted'>No matching opportunities.</div>";
        return;
    }
    list.innerHTML = jobs.map(job => `
      <div class="col-md-6 col-lg-3"><div class="card h-100 p-3">
        <span class="badge text-bg-light align-self-start">${job.skill}</span>
        <h3 class="h5 mt-2">${job.title}</h3><p class="mb-1">${job.company}</p>
        <small class="text-muted">${job.location}</small><strong class="mt-2">₹${job.salary.toLocaleString("en-IN")}</strong>
        <a class="btn btn-sm btn-outline-primary mt-3" href="/jobs/${job.id}">View</a>
      </div></div>`).join("");
}

document.addEventListener("DOMContentLoaded", () => {
    const search = document.getElementById("jobSearch");
    if (search) {
        loadJobs();
        search.addEventListener("input", e => loadJobs(e.target.value.trim()));
    }
});
