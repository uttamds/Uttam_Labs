document.addEventListener("DOMContentLoaded", () => {
    document.querySelectorAll(".alert").forEach(alert => {
        setTimeout(() => alert.classList.add("opacity-75"), 2500);
    });
});
