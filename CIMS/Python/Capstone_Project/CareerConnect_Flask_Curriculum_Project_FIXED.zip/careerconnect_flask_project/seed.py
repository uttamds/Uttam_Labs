from app import create_app, db
from app.models import User, Job, JobApplication

app = create_app()

with app.app_context():
    db.drop_all()
    db.create_all()

    user = User(
        name="Demo Student",
        email="demo@careerconnect.com",
        skills="Python, Flask, SQL, JavaScript",
        career_goal="Full Stack Developer"
    )
    user.set_password("demo123")

    jobs = [
        Job(title="Python Intern", company="CodeCraft", location="Bengaluru", skill="Python", salary=25000),
        Job(title="Junior Flask Developer", company="WebWorks", location="Hyderabad", skill="Flask", salary=40000),
        Job(title="Frontend Developer", company="PixelLabs", location="Pune", skill="JavaScript", salary=35000),
        Job(title="Data Analyst Trainee", company="InsightHub", location="Remote", skill="SQL", salary=30000),
    ]

    db.session.add(user)
    db.session.add_all(jobs)
    db.session.commit()

    db.session.add(JobApplication(
        user_id=user.id, job_id=jobs[0].id,
        status="Applied", notes="Prepare for technical interview."
    ))
    db.session.commit()

    print("Database seeded.")
    print("Demo: demo@careerconnect.com / demo123")
