# CareerConnect – Student Career Hub

A modest but curriculum-complete Flask full-stack reference project for the supplied Python Module curriculum.

## What it demonstrates

- Python basics, conditions, loops, functions, collections, comprehensions
- modules/packages, exceptions, file handling, lambda/map/filter/reduce
- OOP including abstraction, inheritance and polymorphism
- SQL + SQLite/MySQL configuration and SQLAlchemy ORM CRUD
- HTML5, forms, tables, semantic structure, CSS, responsive Bootstrap
- JavaScript DOM/events/ES6/form validation/Fetch API
- Flask routing, Jinja templates, URL parameters, sessions, cookies and flash messages
- REST/JSON endpoints and a Postman collection
- registration/login and Bcrypt password hashing
- environment variables, migration basics and deployment configuration
- frontend -> Flask -> ORM -> database integration

## Run

Windows:
```text
python -m venv venv
venv\Scriptsctivate
pip install -r requirements.txt
copy .env.example .env
python seed.py
flask --app run.py run --debug
```

macOS/Linux:
```text
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
python seed.py
flask --app run.py run --debug
```

Open http://127.0.0.1:5000

Demo account:
`demo@careerconnect.com` / `demo123`

## Database

Default: SQLite in `instance/careerconnect.db`.

For MySQL, change `DATABASE_URL` in `.env`, for example:
`mysql+pymysql://username:password@localhost/careerconnect`

Migration basics:
```text
flask --app run.py db init
flask --app run.py db migrate -m "initial schema"
flask --app run.py db upgrade
```

## REST API

- GET `/api/health`
- GET `/api/jobs`
- GET `/api/jobs?skill=Python`
- GET `/api/jobs/<id>`
- GET `/api/applications`
- POST `/api/applications`
- PUT `/api/applications/<id>`
- DELETE `/api/applications/<id>`

Import `postman/CareerConnect.postman_collection.json` into Postman.

## Curriculum mapping

| Curriculum | Project location |
|---|---|
| Python basics | `seed.py`, `app/utils/data_tools.py`, routes |
| Control statements/functions | `data_tools.py`, routes |
| Lists/tuples/sets/dicts/strings/comprehensions | `data_tools.py`, services |
| Modules/packages/exceptions/files/lambda/map/filter/reduce | `app/utils`, `app/services`, CSV export |
| OOP | `app/services/career_service.py` |
| Database/SQL/CRUD | `app/models.py`, `routes.py`, `api.py` |
| HTML/CSS/Bootstrap | `templates/`, `static/css/` |
| JavaScript/DOM/events/ES6/validation/fetch | `static/js/` |
| Flask basics | `app/__init__.py`, `routes.py`, templates |
| Flask advanced | forms, sessions, cookies, flash, inheritance |
| SQLAlchemy/migrations | `models.py`, `migrations/README.md` |
| REST APIs/Postman | `app/api.py`, `postman/` |
| Authentication/security/env | `auth.py`, Bcrypt, `.env.example` |
| Deployment/GitHub | `Procfile`, `render.yaml`, `.gitignore`, README |
| Final project integration | whole application |

## Teaching idea

Use this as a reference implementation rather than asking students to copy it. Trace one user action end-to-end:

Browser -> JavaScript/HTML -> Flask route -> service -> SQLAlchemy model -> database -> response -> browser.

Then ask students to modify or add a feature.
